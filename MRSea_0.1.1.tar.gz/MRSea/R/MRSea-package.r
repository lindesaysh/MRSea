#' MRSea
#'
#' @name MRSea
#' @docType package
NULL
