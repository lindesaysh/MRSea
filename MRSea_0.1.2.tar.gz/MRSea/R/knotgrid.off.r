#' Knot grid data for offshore example
#'
#' @name knotgrid.off
#' @docType data
NULL
