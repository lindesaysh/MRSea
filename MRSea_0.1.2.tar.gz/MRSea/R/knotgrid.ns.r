#' Knot grid data for nearshore example
#'
#' @name knotgrid.ns
#' @docType data
NULL
